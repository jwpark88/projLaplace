#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;

// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
List matrixmultiplication(int n, int k, int alpha, mat C , int m){
  // in the C code, we have to define character of value
  
  mat A(n, k, fill::randn);
  mat B = A * pow(k, -0.25) ;
  mat phi = pow(C, alpha) * B;
  mat aK =  C * phi;
  mat bK = phi.t() * aK;
  
  return List::create(Named("KPHI") = aK, Named("PHIKPHI") = bK );	
} 




