#############################################################################################
##############################         Package Loading         ##############################
#############################################################################################
library(fields)
library(geoR)
library(geoRglm)
library(Matrix)
library(mgcv)
library(bbmle)
library(Rcpp)
library(RcppArmadillo)
library(ngspatial)
library(MASS)
library(RSpectra)

disc.table <- function(est,se,time){
  L = est - 1.96*se
  U = est + 1.96*se
  print(list("est"=round(c(est,as.numeric(time)),3),"L"=round(L,3),"U"=round(U,3)))
}

##########################################################################################
#########################                 Q.b               ##############################
##########################################################################################

## Case Binomial
Q.d.poisson <- function(d,Xbeta,Y,det.Sigma,inv.Sigma,M){
  eta = as.numeric(Xbeta + M%*%d)
  dens = sum(dpois(Y,exp(eta),log=TRUE)) +
    my.gauss.d(d,det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)
  return(dens)
}

## Case Binomial
Q1.d.poisson <- function(d,Xbeta,Y,det.Sigma, inv.Sigma,M){
  eta = as.numeric(Xbeta + M%*%d)
  grad <- t(t(M)%*%Y) - t(exp(eta))%*%M - t(d)%*%inv.Sigma
  return(grad)
}

## Case Binomial
Q2.d.poisson <- function(d, Xbeta,Y,det.Sigma,inv.Sigma,M){
  eta = as.numeric(Xbeta + M%*%d)
  nHess = t(M)%*%diag(exp(eta))%*%M + inv.Sigma
  Hess <- -nHess
  return(Hess)
}

#- Gausian Density Part -#
my.gauss.d <- function(d, det.Sigma, inv.Sigma){
  n <- length(d)
  dens <- (-n/2) * log(2*pi) + (1/2)*det.Sigma - (1/2) * t(d) %*% inv.Sigma %*% d
  return(dens)
}


##########################################################################################
#########################          Newton-Raphson           ##############################
##########################################################################################

newton_raphson <- function(initial, score, hessian, tolerance = 0.001, max.iter, m.dim,...){
  solution <- matrix(NA, max.iter, m.dim)                             
  solution[1,] <- initial                                             
  for(i in 2:max.iter){
    HSS <- hessian(initial, ...)                                      
    SCR <- t(score(initial, ...))                                     
    solution[i,] <- initial - solve(HSS, SCR)                         
    initial <- solution[i,]                                           
    convergence <- abs(solution[i,] - solution[i-1,])                 
    if(all(convergence < tolerance)==TRUE) break                      
  }
  output <-  list()
  output[1][[1]] <- HSS                                               
  output[2][[1]] <- initial                                           
  #DELTA.HAT <<- initial    
  #print("newton")
  return(output)
}


##########################################################################################
#########################              LAPLACE              ##############################
##########################################################################################


laplace <- function(Q.b, gr, hess, method, optimizer, m.dim, ...){
  log.integral <- -sqrt(.Machine$double.xmax)                      
  inicial <- rep(0,m.dim)                                          
  if (method=="BFGS"){
    temp <- try(optim(inicial, Q.b, gr = gr, ...,
                      method = optimizer, hessian = TRUE, control = list(fnscale=-1)), silent = TRUE)}
  if (method=="NR"){
    temp <- try(newton_raphson(initial = inicial, score=gr, hessian = hess, m.dim = m.dim, max.iter = 100,...), silent = TRUE)}
  if(class(temp)!='try-error' & method =="BFGS"){                
    log.integral <- temp$value + ((m.dim/2)*log(2*pi) - 0.5*determinant(-temp$hessian)$modulus)}
  if(class(temp)!='try-error' & method=="NR"){                   
    value <- Q.b(d = temp[2][[1]] , ...)                         
    log.integral <- value + ((m.dim/2)*log(2*pi) - 0.5*determinant(-temp[1][[1]])$modulus)}   
  if(method=="NR"){
    assign("pred",value = temp[2][[1]], envir= .preditos)        
  }
  if(method=="BFGS"){
    assign("pred",value = temp$par, envir = .preditos)
  }
  return(log.integral)
}


##########################################################################################
#########################        Neg-logLikelihood          ##############################
##########################################################################################



nlikGLGM <- function(par, Y, X, nugget, family, method, ntrial=1, offset=NA,
                     M,Q,MQM,rank){
  #print(par)                                                               
  I = -sqrt(.Machine$double.xmax)       
  n <- length(Y)                        
  n.beta <- dim(X)[2]                   
  beta <- as.numeric(par[1:n.beta])
  Xbeta <- X%*%beta
  if(is.na(offset)[1] != TRUE){Xbeta <- cbind(X,log(offset))%*%c(beta,1)}
  tau <- as.numeric(exp(par[(n.beta+1)]))           
  ######## Assembling the covariance matrix
  det.Sigma <- rank*log(tau)
  inv.Sigma <- tau * MQM
  if(family == "poisson"){
    I <- laplace(Q.d.poisson, gr = Q1.d.poisson, hess = Q2.d.poisson, method= method, optimizer="BFGS", 
                 m.dim = rank, M = M,                                        
                 Xbeta = Xbeta, Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)}
  return(-I)                                                   
}



##########################################################################################
#########################            Fit Function           ##############################
##########################################################################################


glgm <- function(formula, inits, data , nugget, family, ntrial=1,
                 method.optim, method.integrate, predict=TRUE,rank=50, A, offset = 1){
  BEFORE.M = Sys.time()
  formula <- as.formula(formula)
  mf <- model.frame(formula, data=data)
  Y <- model.response(mf)
  X <- model.matrix(formula, data=data)
  names <- c(colnames(X), "logtau")
  n.beta <- dim(X)[2]
  n.obs <- dim(X)[1]
  
  # constructing M, Q, MQM
  P.perp = diag(1,n.obs) - X%*%solve(t(X)%*%X)%*%t(X)
  eig = eigs_sym(P.perp %*% A %*% P.perp,k=rank,which="LA")
  eigenvalues = eig$values
  M = eig$vectors[,c(1:rank)]
  Q = diag(rowSums(A),n.obs) - A
  MQM = t(M) %*% Q %*% M
  AFTER.M = Sys.time()
  
  #print(AFTER.M - BEFORE.M)
  names(inits) <- parnames(nlikGLGM) <- names                            
  estimate <- mle2(nlikGLGM, start=inits,          
                   vecpar=TRUE,
                   method=method.optim,                                  
                   control = list(maxit=1000),     
                   skip.hessian = FALSE,
                   data = list(Y=Y, X=X, family= family, method = method.integrate, ntrial,
                               offset = offset, M = M, MQM = MQM, rank = rank)) 
  AFTER.E = Sys.time()
  #print(AFTER.E - AFTER.M)
  n.pars <- length(coef(estimate))
  summary.estimate <- summary(estimate)
  summary.estimate@coef[,1][c(n.beta+1):n.pars] <- summary.estimate@coef[,1][c(n.beta+1):n.pars]
  std.error = sqrt(diag(estimate@vcov))
  summary.estimate@coef[,2] <- std.error
  summary.estimate@coef[,3] <- NA
  summary.estimate@coef[,4] <- NA
  if(predict == TRUE) {                                                          
    output <- list()
    output[1][[1]] <- summary.estimate
    output[2][[1]] <- AFTER.E - BEFORE.M
    output[3][[1]] <- estimate@vcov
    output[4][[1]] <- estimate
    return(output)}
  if(predict == FALSE){return(estimate)}
}

