# Version 1.0 
# Date : 2020.02.07

#############################################################################################
##############################         Package Loading         ##############################
#############################################################################################
library(fields)
library(geoR)
library(geoRglm)
library(Matrix)
library(mgcv)
library(bbmle)
library(Rcpp)
library(RcppArmadillo)
library(ngspatial)
library(MASS)
library(RSpectra)
sourceCpp(paste0(getwd(),"/rp.cpp"))   
sourceCpp(paste0(getwd(),"/matrixmultiplication.cpp"))

#############################################################################################
##############################           ExtraFunction         ##############################
#############################################################################################


## Inverse by logit
inv.logit <- function(x) {1/(1+exp(-x))}
logit <- function(x) {log(x) - log(1-x)}

covfndef <- function(nu){
  # exponential 
  if(nu == 1/2) covfn <- function(dist,phi) { 
    K = exp(-1/phi*dist) 
    return(K)
  }
  # matern 1.5
  if(nu == 1.5) covfn <- function(dist,phi) { 
    K = (1+sqrt(3)/phi*dist)*exp(-sqrt(3)/phi*dist)
    return(K)
  }
  # matern 2.5
  if(nu == 2.5 ) covfn <- function(dist,phi) { 
    K = (1+sqrt(5)/phi*dist+ 5/(3*phi^2)*dist^2)*exp(-sqrt(5)/phi*dist)
    return(K)
  }
  # square exponential
  if(nu ==10) covfn <- function(dist,phi) { 
    K = exp(-1/(2*phi^2)*dist^2) 
    return(K)
  }
  return(covfn)
}

plotRef <- function(spatialdata, vals,...){
  library(sp)
  library(gstat)
  library(nlme)
  library(fields)
  library(classInt)
  library(maps)
  
  pal <- tim.colors(8)
  ints <- classIntervals(vals, n = 8, style = "pretty") # Determine breakpoints
  intcols <- findColours(ints, pal) # vector of colors
  
  plot(spatialdata, col = intcols, pch = 19,xlab="",ylab="")
}
legend.col <- function(col, lev){
  opar <- par
  n <- length(col)           
  bx <- par("usr")
  
  box.cx <- c(bx[2] + (bx[2] - bx[1]) / 1000,
              bx[2] + (bx[2] - bx[1]) / 1000 + (bx[2] - bx[1]) / 50)
  box.cy <- c(bx[3], bx[3])
  box.sy <- (bx[4] - bx[3]) / n
  
  xx <- rep(box.cx, each = 2)
  
  par(xpd = TRUE)
  for(i in 1:n){
    yy <- c(box.cy[1] + (box.sy * (i - 1)),
            box.cy[1] + (box.sy * (i)),          
            box.cy[1] + (box.sy * (i)),
            box.cy[1] + (box.sy * (i - 1)))
    polygon(xx, yy, col = col[i], border = col[i])           
  }
  par(new = TRUE)
  plot(0, 0, type = "n",
       ylim = c(min(lev), max(lev)),
       yaxt = "n", ylab = "",
       xaxt = "n", xlab = "",
       frame.plot = FALSE)
  axis(side = 4, las = 2, tick = FALSE, line = .25)
  par <- opar
}

#############################################################################################
##############################             Covariance          ##############################
#############################################################################################


matern.cov <- function(phi,kappa,mat.dist) {
  if(phi < 1e-8 ) phi = 0.0001                                                
  if(kappa == 2.5){
    K = (1+sqrt(5)/phi*mat.dist+ 5/(3*phi^2)*mat.dist^2)*exp(-sqrt(5)/phi*mat.dist)
  }
  return(K)
}

rp_fl <- function(n=1000,k=100,C,alpha=1,m=50){
  K_rcpp = matrixmultiplication(n=n,k=k,alpha=1,C=C,m=m)
  K11 = K_rcpp$PHIKPHI
  KPHI = K_rcpp$KPHI
  SVDK11 = svd(K11)
  V11 = SVDK11$u
  L11 = SVDK11$d
  C = KPHI%*%V11%*%diag(L11^-0.5)
  C.svd = svd(C)
  u_m = C.svd$u[,1:m]
  d_m = C.svd$d[1:m]
  #- D^2 will be after this function -#
  return(list("u" = u_m, "d" = as.matrix(d_m,ncol=1)))
}

sigma.rp <- function(phi,kappa,mat.dist,U1,rank){
  covmat_original <- matern.cov(phi=phi,kappa=kappa,mat.dist=mat.dist)
  covmat_rp <- rp_fl(n=dim(mat.dist)[1],k=2*rank,alpha=1,C=covmat_original,m=rank)
  m <- rank
  um <- covmat_rp$u[,1:m]
  signdiag = sign(diag(t(um)%*%U1))
  signdiag = as.logical(1-signdiag)
  um[,signdiag] = -um[,signdiag]
  dm <- diag(covmat_rp$d[1:m,]^2)
  return(list(um=um ,dm = dm))
}

sigma.spectra <- function(phi,kappa,mat.dist,U1,rank){
  covmat_original <- matern.cov(phi=phi,kappa=kappa,mat.dist=mat.dist)
  covmat_svd <- eigs_sym(covmat_original,k=rank,which="LA")
  m <- rank
  um <- covmat_svd$vectors[,1:m]
  signdiag = sign(diag(t(um)%*%U1)) 
  signdiag = as.logical(1-signdiag)
  um[,signdiag] = -um[,signdiag]
  dm <- diag(covmat_svd$values[1:m])
  return(list(um=um ,dm = dm))
}




##########################################################################################
#########################               Q.b.s               ##############################
##########################################################################################


## Case Poisson
Q.b.poisson <- function(b,Xbeta,Y, det.Sigma, inv.Sigma,um,dm){
  eta = Xbeta + um%*%dm^0.5%*%b                 
  dens = sum(dpois(Y,lambda= exp(eta), log=TRUE)) +
    my.gauss(b,det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)  
  return(dens)
}

Q1.b.poisson <- function(b,Xbeta,Y,det.Sigma, inv.Sigma,um,dm){
  grad <- t(dm^0.5%*%t(um)%*%Y) - t(exp(Xbeta + um%*%dm^0.5%*%b))%*%um%*%dm^0.5 - t(b)*inv.Sigma  
  return(grad)
}

Q2.b.poisson <- function(b, Xbeta,Y,det.Sigma,inv.Sigma,um,dm){
  m = dim(dm)[1]
  eta = exp(Xbeta + um%*%dm^0.5%*%b)
  nHess = dm^0.5%*%t(um)%*%diag(as.numeric(eta))%*%um%*%dm^0.5 + diag(inv.Sigma,m)
  Hess <- -nHess
  return(Hess)
}

## Case Binomial
Q.b.binomial <- function(b,Xbeta,Y,det.Sigma,inv.Sigma,ntrial=1,um,dm){
  eta = Xbeta + um%*%dm^0.5%*%b
  p <- inv.logit(eta)
  dens = sum(dbinom(Y,size = ntrial, prob = p,log=TRUE)) + my.gauss(b,det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)
  return(dens)
}
Q1.b.binomial <- function(b,Xbeta,Y,det.Sigma, inv.Sigma,ntrial=1,um,dm){
  eta = Xbeta + um%*%dm^0.5%*%b
  b1 <- ntrial*inv.logit(eta)
  grad <- t(dm^0.5%*%t(um)%*%Y) - t(b1)%*%um%*%dm^0.5 - t(b)*inv.Sigma
  return(grad)
}
Q2.b.binomial <- function(b, Xbeta,Y,det.Sigma,inv.Sigma,ntrial=1,um,dm){
  m = dim(dm)[1]
  eta = as.numeric(Xbeta + um%*%dm^0.5%*%b)
  nHess = ntrial*dm^0.5%*%t(um)%*%diag( exp(eta)/(1+exp(eta))^2 )%*%um%*%dm^0.5 + diag(inv.Sigma,m)
  Hess <- -nHess
  return(Hess)
}

## Case NegBinomial
Q.b.negbin <- function(b,Xbeta,Y,prec,det.Sigma,inv.Sigma,um,dm){
  eta = Xbeta + um%*%dm^0.5%*%b
  dens = sum(dnbinom(Y,size = prec, mu = exp(eta),log=TRUE)) + my.gauss(b,det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)
  return(dens)
}
Q1.b.negbin <- function(b,Xbeta,Y,prec,det.Sigma,inv.Sigma,um,dm){
  et1 = exp(Xbeta)
  et2 = exp(um%*%dm^0.5%*%b)
  et12 = et1*et2
  grad <- t(dm^0.5%*%t(um)%*%Y) - t((prec+Y)*(et12*(et12+prec)^-1))%*%um%*%dm^0.5 - t(b)*inv.Sigma
  return(grad)
}
Q2.b.negbin <- function(b, Xbeta,Y,prec,det.Sigma,inv.Sigma,um,dm){
  m = dim(dm)[1]
  et1 = exp(Xbeta)
  et2 = exp(um%*%dm^0.5%*%b)
  et12 = et1*et2
  p1 <- et12*((et12+prec)^-1)
  p2 <- p1^2
  D <- p1-p2
  nHess = dm^0.5%*%t(um)%*%diag(as.numeric((prec+Y)*D))%*%um%*%dm^0.5 + diag(inv.Sigma,m)
  Hess <- -nHess
  return(Hess)
}

#- Gausian Density Part -#
my.gauss <- function(b, det.Sigma, inv.Sigma){
  n <- length(b)
  dens <- (-n/2) * log(2*pi) -(1/2)*det.Sigma - (1/2)*inv.Sigma * t(b)  %*% b
  return(dens)
}


##########################################################################################
#########################          Newton-Raphson           ##############################
##########################################################################################

newton_raphson <- function(initial, score, hessian, tolerance = 0.001, max.iter, m.dim,...){
  solution <- matrix(NA, max.iter, m.dim)                             
  solution[1,] <- initial                                             
  for(i in 2:max.iter){
    HSS <- hessian(initial, ...)                                      
    SCR <- t(score(initial, ...))                                     
    solution[i,] <- initial - solve(HSS, SCR)                         
    initial <- solution[i,]                                           
    convergence <- abs(solution[i,] - solution[i-1,])                 
    if(all(convergence < tolerance)==TRUE) break                      
  }
  output <-  list()
  output[1][[1]] <- HSS                                               
  output[2][[1]] <- initial                                           
  DELTA.HAT <<- initial    
  #print("newton")
  return(output)
}

##########################################################################################
#########################              LAPLACE              ##############################
##########################################################################################



laplace <- function(Q.b, gr, hess, method,m.dim=50, ...){
  log.integral <- -sqrt(.Machine$double.xmax)                      
  inicial <- rep(0,m.dim)                                         
  temp <- try(newton_raphson(initial = inicial, score=gr, hessian = hess,m.dim = m.dim, max.iter = 100,...), silent = TRUE)
  if(class(temp)!='try-error'){                   
    value <- Q.b(b = temp[2][[1]] , ...)                         
    log.integral <- value + ((m.dim/2)*log(2*pi) - 0.5*determinant(-temp[1][[1]])$modulus)} 
  return(log.integral)
}



##########################################################################################
#########################        Neglog-Likelihood          ##############################
##########################################################################################

nlikGLGM <- function(par, Y, X, kappa, nugget, mat.dist, cov.model, family, method, ntrial=1, offset=NA,U1,rank,
                     projoption){
  #print(par)                                                   
  I = -sqrt(.Machine$double.xmax)       
  n <- length(Y)                        
  n.beta <- dim(X)[2]                   
  beta <- as.numeric(par[1:n.beta])     
  Xbeta <- X%*%beta
  if(is.na(offset)[1] != TRUE) { Xbeta <- cbind(X,log(offset))%*%c(beta,1)}   
  sigma <- exp(as.numeric(par[c(n.beta+1)]))
  if(sigma < 1e-8) sigma = 0.00001
  phi <- exp(as.numeric(par[c(n.beta+2)]))
  if(nugget == TRUE){ tau2 <- exp(as.numeric(par[c(n.beta+3)]))}                
  if(nugget == FALSE) {tau2 <- 0}                                               
  if(kappa != "NULL"){ kappa = exp(as.numeric(kappa))}
  if(family == "negative.binomial") { prec <- exp(as.numeric(par[c(n.beta+3)]))}
  ######## Assembling the covariance matrix
  if(projoption == "svd") { 
    Sigma <- sigma.spectra(phi=phi,kappa=kappa,mat.dist=mat.dist,U1=U1,rank=rank)
  } else {
    Sigma <- sigma.rp(phi=phi,kappa=kappa,mat.dist=mat.dist,U1=U1,rank=rank)
  }
  um <- Sigma$um
  dm <- Sigma$dm                       
  m <- rank
  UM<<-um
  DM<<-dm
  #print("Random Projection")
  det.Sigma <- m * log(sigma)  
  inv.Sigma <- 1 / sigma
  if(family == "poisson"){
    I <- laplace(Q.b.poisson, gr = Q1.b.poisson, hess = Q2.b.poisson, method = "NR", 
                 m.dim = m,um = um,dm = dm,                                             
                 Xbeta = Xbeta, Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)}
  if(family == "binomial"){
    I <- laplace(Q.b.binomial, gr = Q1.b.binomial, hess = Q2.b.binomial,method =  "NR",
                 m.dim = m, um = um, dm = dm,
                 Xbeta = Xbeta, Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma,
                 ntrial = ntrial)}
  if(family == "negative.binomial"){
    I <- laplace(Q.b.negbin, gr = Q1.b.negbin, hess = Q2.b.negbin, method =  "NR",
                 m.dim = m, um = um, dm = dm,
                 Xbeta = Xbeta, prec = prec,Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)}
  return(-I)                                                   
}


nlikGLGM_pca <- function(par,rank,family,method,X,Y,mat.dist){
  #print(par)                                                             
  I = -sqrt(.Machine$double.xmax)       
  n <- length(Y)                        
  n.beta <- dim(X)[2]                   
  beta <- as.numeric(par[1:n.beta])     
  Xbeta <- X%*%beta
  sigma <- as.numeric(exp(par[c(n.beta+1)]))
  phi <- as.numeric(exp(par[c(n.beta+2)]))
  if( is.na(par[c(n.beta+3)]) != TRUE) { prec <- as.numeric(exp(par[c(n.beta+3)])) }
  ######## Assembling the covariance matrix
  Sigma <- sigma.spectra(phi = phi,kappa = 2.5,mat.dist = mat.dist,U1=U1,rank=rank)
  um <- Sigma$um
  dm <- Sigma$dm
  m <- rank
  #print("dm")
  det.Sigma <- m * log(sigma)  
  inv.Sigma <- 1 / sigma
  ntrial <- 1                                             
  if(family == "poisson"){
    I <- laplace(Q.b.poisson, gr = Q1.b.poisson, hess = Q2.b.poisson, method = method,
                 m.dim = m,um = um,dm = dm,                                             
                 Xbeta = Xbeta, Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)}
  if(family == "binomial"){
    I <- laplace(Q.b.binomial, gr = Q1.b.binomial, hess = Q2.b.binomial,method = method,
                 m.dim = m, um = um, dm = dm,
                 Xbeta = Xbeta, Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma,
                 ntrial= ntrial)}
  if(family == "negative.binomial"){
    I <- laplace(Q.b.negbin, gr = Q1.b.negbin, hess = Q2.b.negbin, method = method,
                 m.dim = m, um = um, dm = dm,
                 Xbeta = Xbeta, prec = prec,Y = Y, det.Sigma = det.Sigma, inv.Sigma = inv.Sigma)}
  return(-I)                                                   
}

##########################################################################################
#########################            Fit Function           ##############################
##########################################################################################

glgm <- function(formula, cov.model, kappa ,inits, data ,coords, nugget, family, ntrial=1,
                 offset=1, method.optim, method.integrate, predict=TRUE, projoption = "rp",
                 control=list(maxit=100,ndeps=rep(1e-2,4),reltol=1e-2), rank=50,n.hessian=TRUE){
  START.time <- Sys.time()
  formula <- as.formula(formula)
  mf <- model.frame(formula, data=data)
  Y <- model.response(mf)
  X <- model.matrix(formula, data=data)
  mat.dist <- as.matrix(rdist(coords,coords))                      
  names <- c(colnames(X), "logsigma2", "logphi")
  n.beta <- dim(X)[2]
  n <- dim(X)[1]
  # keep sign values
  sign.cov <- as.matrix(matern.cov(phi=exp(inits['logphi']),kappa=exp(kappa),mat.dist=mat.dist))
  sign.temp <- rp_fl(n = n,k=2*rank,alpha=1,C = sign.cov,m=rank)
  U1 <<- sign.temp$u[,1:rank]
  
  # Pois Distn with nugget effect
  if(family == "poisson" & nugget == TRUE){names <- c(names,"logtau2")}
  if(family == "negative.binomial"   & nugget == FALSE){names <- c(names,"logprec")}
  names(inits) <- parnames(nlikGLGM) <- names                            
  estimate <- mle2(nlikGLGM, start=inits,                   
                   vecpar=TRUE,
                   method=method.optim,                                  
                   control = control,                
                   skip.hessian = TRUE,
                   data = list(Y=Y, X=X, mat.dist=mat.dist, cov.model=cov.model, ntrial=ntrial, nugget=nugget,
                               family= family, method = method.integrate, kappa = kappa, offset = offset,U1 = U1,
                               rank = rank, projoption = projoption))
  EST.time <- Sys.time()
  #cat("estimate done\n")
  estimate_hessian <- estimate@coef
  if(n.hessian){
    output.hessian.pca <- optimHess(estimate_hessian,fn=nlikGLGM_pca,rank=rank,family=family,
                                    method=method.integrate,X=X,Y=Y,mat.dist=mat.dist)
    output.se <- sqrt(diag(solve(output.hessian.pca)))
    #cat("hessian done\n")
    HSS.time <- Sys.time()
  } else { 
    output.hessian.pca = NA
    output.se <- NA
    HSS.time <- Sys.time()
    #cat("hessian not done\n")
  }
  n.pars <- length(coef(estimate))
  summary.estimate <- summary(estimate)
  summary.estimate@coef[,1][c(n.beta+1):n.pars] <- summary.estimate@coef[,1][c(n.beta+1):n.pars]
  summary.estimate@coef[,2] <- output.se
  summary.estimate@coef[,3] <- NA
  summary.estimate@coef[,4] <- NA
  output <- list()
  output[1][[1]] <- summary.estimate
  output[2][[1]] <- c("ESTIMATION"= EST.time-START.time, "HESSIAN"= HSS.time - EST.time)
  output[3][[1]] <- output.hessian.pca
  output[4][[1]] <- estimate
  return(output)
}




