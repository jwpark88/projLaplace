#################################################################################################################
###########################                         DATA GENERATION                           ###################
#################################################################################################################

rglmm.sim <- function(family,seed,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=1000,n.pred=400){
  set.seed(seed)
  p.true = c(kappa,sigma,phi)
  beta.true = beta
  n = n
  n.pred = n.pred
  covfn<-covfndef(p.true[1]) # define the covariance function
  coords.all<- matrix(runif((n+n.pred)*2),ncol=2,nrow=n+n.pred) # simulate data locations
  X.all <- matrix(runif((n+n.pred)*2),ncol=2,nrow=(n+n.pred))
  dist.all <- fields::rdist(coords.all,coords.all) # compute distance matrix
  V.all <- p.true[2]*covfn(dist.all,p.true[3]) # compute covariance matrix
  r.e.all <- mgcv::rmvn(1,rep(0,nrow(coords.all)),V.all) # simulate random effects
  if(family=="poisson"){
    lambda.all <- exp(X.all%*%beta.true+r.e.all) # conditional expection for Poisson process
    Y.all <- rpois(length(lambda.all), lambda.all) # simulate Poisson observations
    return(list(Y.all=Y.all,X.all = X.all,
                dist.all = dist.all,coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                lambda.all=lambda.all))
  }
  if(family=="binomial"){
    pi.all = X.all%*%beta.true + r.e.all # linear model
    p.all <- exp(pi.all)/(1+exp(pi.all)) # compute the probability of z = 1 for binary process
    Y.all <- sapply(p.all, function(x) sample(0:1, 1, prob = c(1-x, x))) # simulate binary observations
    return(list(Y.all=Y.all, X.all = X.all,
                dist.all = dist.all, coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                pi.all = pi.all , p.all=p.all))
  }
  if(family=="negative.binomial"){
    mu.all <- exp(X.all%*%beta.true+r.e.all) # conditional expection for Poisson process
    Y.all <- rnbinom(length(mu.all), mu=mu.all,size=prec) # simulate Poisson observations
    return(list(Y.all=Y.all, X.all = X.all,
                dist.all = dist.all,coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                mu.all= mu.all))
  }
}


start.glmm <- function(formula,family,data,ntrial=1){
  if(family=="poisson"){
    fit<- glm(formula,data=data,family="poisson") 
    esp <- predict(fit,data)
    sigma <- var( esp - log(Y+1))
    phi <- 0.1*max(dist(coords))                                                                  
    startinit <- c(coef(fit),log(sigma),log(phi))
    return(startinit)
  }
  if(family=="binomial"){
    fit<- glm(formula,data=data,family=binomial) 
    esp <- predict(fit, type="response")
    ntrial = ntrial
    sigma = var(Y/ntrial - esp)
    phi <- 0.1*max(dist(coords))                                                                  
    startinit <- c(coef(fit),log(sigma),log(phi))
    return(startinit)
  }
  if(family=="negative.binomial"){
    fit <- glm.nb(formula,data=data)
    esp <- predict(fit,data)
    sigma <- var( esp - log(Y+1))
    phi <- 0.1*max(dist(coords))
    prec <- fit$theta
    startinit <- c(coef(fit),log(sigma),log(phi))
    startinit[length(startinit)+1] = log(prec)
    return(startinit)
  }
}

pred.glmm.plot <- function(estimate,UM,DM,DELTA.HAT,dist.all,r.e.all,coords.all,pdf.name=NA,save=FALSE){
  cat("phi & kappa must be original scale(not log scale)\n")
  n = dim(UM)[1]
  n.pred = length(r.e.all)-n
  UD = UM %*% diag(diag(DM)^0.5)
  UD_inv = UM %*% diag(diag(DM)^-0.5)
  UD_inv_DU = UM %*% diag(diag(DM)^-1) %*% t(UM)
  S.hat = estimate[3] * matern.cov(phi = estimate[4], kappa = 2.5, mat.dist = dist.all)
  W.hat = UD %*% DELTA.HAT
  W.star = ( 1 / estimate[3] ) *  S.hat[(n+1):(n+n.pred),1:n] %*% UD_inv_DU %*% W.hat
  W = r.e.all[1:n]
  W.tilda = r.e.all[(n+1):(n+n.pred)]
  coords = coords.all[1:n,]
  coords.pred = coords.all[(n+1):(n+n.pred),]
  r.e = r.e.all[1:n]
  
  temp.name = paste(pdf.name,".pdf",sep="")
  if(save){
    pdf(temp.name, width=10, height=10)
    par(mfrow=c(2,2))
    par(mar=c(3,3,3,3))
    plotRef(coords,W)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Simulated Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords,W.hat)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Estimated Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords.pred,W.tilda)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Hold-out Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords.pred,W.star)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Predicted Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    dev.off()
  } else{
    par(mfrow=c(2,2))
    par(mar=c(3,3,3,3))
    plotRef(coords,W)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Simulated Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords,W.hat)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Estimated Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords.pred,W.tilda)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Hold-out Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
    plotRef(coords.pred,W.star)
    legend.col(col = tim.colors(8), lev = seq(min(r.e),max(r.e),length=10))
    mtext("Predicted Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
  }
}


table.rank <- function(result){
  est = result[1][[1]]@coef[,1]
  est.s2phi = result[1][[1]]@coef[3,1] - result[1][[1]]@coef[4,1]
  est = c(est,est.s2phi)
  
  cov = solve(result[3][[1]])
  se = sqrt(diag(cov))
  se.s2phi = sqrt(cov[3,3] + cov[4,4] - 2*cov[3,4])
  se = c(se,se.s2phi)
  L = round(est - 1.96*se,3)
  U = round(est + 1.96*se,3)
  time <- result[2][[1]][1] + result[2][[1]][2]
  ESTIMATION = round(c(est,time),3)
  return(list("EST" = ESTIMATION,"LowerBound" = L,"Upperbound" = U))
}
