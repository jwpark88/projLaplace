rm(list=ls())
##########################################################################################################

source("poisDiscreteFLsource.R")


##############################################################################################################
########################################                INFANT              ##################################
##############################################################################################################

data("infant")
data(A)
infant
head(infant)
infant$low_weight = infant$low_weight / infant$births
# Intercept, Low birth weight, Black, Hispanic, Gini, Affluence, Stability, tau
linmod <- glm(deaths~low_weight+black+hispanic+gini+affluence+stability+offset(log(births)),data=infant,family="poisson") # Find starting values
linmod$coefficients
starting <- c(linmod$coefficients,"logtau"=log(1/var(linmod$residuals)) )
starting 

X = cbind(1, infant$low_weight, infant$black, infant$hispanic, infant$gini, infant$affluence, infant$stability)
X = as.matrix(X)
Y = as.matrix(infant$deaths,ncol=1)

data.infant = data.frame(X,Y)
colnames(data.infant) = c("intercept_",names(starting[2:7]),"Y")

result.infant <- glgm(Y~.-1,data=data.infant,inits=starting,nugget=FALSE,family="poisson",method.optim = "BFGS",
                      method.integrate = "NR",predict = TRUE,A = A,rank=100, offset = infant$births)

est = result.infant[1][[1]]@coef[,1]
se = result.infant[1][[1]]@coef[,2]
time = as.numeric(result.infant[2][[1]])

##############################################################################################################
########################################                RESULT              ##################################
##############################################################################################################

disc.table <- function(est,se,time){
  L = est - 1.96*se
  U = est + 1.96*se
  print(list("est"=round(c(est,as.numeric(time)),3),"L"=round(L,3),"U"=round(U,3)))
}

disc.table(est,se,time)
