rm(list=ls())
##########################################################################################################

source("FLsource.R")
source("FLSimulsource.R")

###########################################################################################################
##########################################     SET      ###################################################
###########################################################################################################

load("thickness_obs.RData")

image( thickness.obs )
hist( thickness.obs )

mean(Y.all)

Y.all[thickness.obs>1000] =1
Y.all[thickness.obs<=1000] =0

image(Y.all)
dim(Y.all)

x.coords.all = seq(0,1,length=nrow(Y.all))
y.coords.all = seq(0,1,length=nrow(Y.all))
Y.all_vec = as.numeric(Y.all)

x.coords.merge = rep(x.coords.all,each=ncol(Y.all))
y.coords.merge = rep(y.coords.all,times=nrow(Y.all))
ICE = data.frame("Y" = Y.all_vec,"x.coords" = x.coords.merge,"y.coords" = y.coords.merge)
dim(ICE)

set.seed(1)
id.all = sample(1:171^2, 8000, replace=FALSE )
id.temp = sample(1:8000,6400,replace=FALSE)
id.train = sort(id.all[id.temp])
id.test = sort(id.all[-id.temp])
ICE_train = ICE[id.train,]
coords_train <- cbind(ICE_train$x.coords,ICE_train$y.coords)
dim(coords_train)


###########################################################################################################
##########################################      RUN      ##################################################
###########################################################################################################

#- Initial value -#
fit<- glm(Y~.,data=ICE_train,family=binomial) 
esp <- predict(fit, type="response")
ntrial = 1
sigma = var(ICE_train$Y/ntrial - esp)
phi <- 0.1*max(dist(coords_train))                                                                  
startinit <- c(coef(fit),log(sigma),log(phi))
names(startinit) <- c("(intercept)",colnames(ICE_train)[2:3],"logsigma2","logphi")
startinit

#- Run -#
result_ICE <- glgm(Y ~ .,cov.model="matern",kappa = log(2.5),inits = startinit,data = ICE_train,nugget=FALSE,
                   coords = coords_train,family="binomial",method.optim = "CG",method.integrate = "NR",ntrial=1,
                   offset = NA,predict=TRUE,control=list(maxit=1000,ndeps=rep(0.01,5),reltol=0.01),rank=100)
result_ICE[1][[1]] # COEF(beta,logsigma2,logphi)
result_ICE[2][[1]] # ESTIMATION TIME
result_ICE[3][[1]] # HESSIAN


###########################################################################################################
##########################################      SAVE     ##################################################
###########################################################################################################
# 
# write.csv(result_ICE[1][[1]]@coef[,1],"ICE_Estimation.csv",row.names = FALSE)
# write.csv(result_ICE[3][[1]],"ICE_Hessian.csv",row.names = FALSE)
# write.csv(as.numeric(result_ICE[2][[1]][1] + result_ICE[2][[1]][2]),"ICE_time.csv",row.names = FALSE)
# write.csv(sqrt(diag(solve(result_ICE[3][[1]]))),"ICE_StdErr.csv",row.names = FALSE)
# write.csv(UM,"ICE_UM.csv",row.names=FALSE)
# write.csv(DM,"ICE_UM.csv",row.names=FALSE)
# write.csv(DELTA.HAT,"ICE_DELTAHAT.csv",row.names=FALSE)
# 
###########################################################################################################
##########################################     RESULT    ##################################################
###########################################################################################################

est = as.numeric(read.csv("ICE_Estimation.csv")[,1])
se = sqrt(diag(solve(as.matrix(read.csv("ICE_Hessian.csv")))))
time = as.numeric(read.csv("ICE_Time.csv")[,1])
disc.table(est,se,time)


###########################################################################################################
##########################################      PRED     ##################################################
###########################################################################################################


ICE_test = ICE[id.test,]
ICE_data = rbind(ICE_train,ICE_test) 
coords.all = cbind(ICE_data$x.coords,ICE_data$y.coords)
dist.all = rdist(coords.all)

UD = UM %*% diag(diag(DM)^0.5)
UD_inv = UM %*% diag(diag(DM)^-0.5)
UD_invU = UM %*% diag(diag(DM)^-1) %*% t(UM)

final_estimate = ESTIMATION
final_estimate[4:5] = exp(final_estimate[4:5])
S.hat = final_estimate[4] * matern.cov(phi = final_estimate[5], kappa = 2.5, mat.dist = dist.all)

W.hat = UD %*% DELTA.HAT
W.star = ( 1 / final_estimate[3] ) *  S.hat[6401:8000,1:6400] %*% UD_invU %*% W.hat

#W = r.e.all[1:6400]
#W.tilda = r.e.all[1001:1400]

coords.all
coords = cbind(ICE_train$x.coords,ICE_train$y.coords)
coords.pred = coords.all[6401:8000,]
c1 = cbind(coords[,2],coords[,1])
c2 = cbind(coords.all[6401:8000,2],coords.all[6401:8000,1])
W.all = c(W.hat,W.star)


pdf("ICE_randomeffect.pdf", width=20, height=10)
par(mfrow=c(1,2))
par(mar=c(3,3,3,3))
plotRef(c1,W.hat)
legend.col(col = tim.colors(8), lev = seq(min(W.all),max(W.all),length=10))
mtext("Estimated Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)

plotRef(c2,W.star)
legend.col(col = tim.colors(8), lev = seq(min(W.all),max(W.all),length=10))
mtext("Predicted Random Effects", side = 3, line = 1, adj = 0, cex = 1.5)
dev.off()


###########################################################################################################
##########################################      PLOT     ##################################################
###########################################################################################################


temp2_1 = as.data.frame(ICE_train[ICE_train$Y==1,])
temp2_0 = as.data.frame(ICE_train[ICE_train$Y==0,])
plot(x=temp2_1$y.coords,y=temp2_1$x.coords,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Observed Ice Sheet Presence")
points(x=temp2_0$y.coords,y=temp2_0$x.coords,col="#00008b",pch=16,cex=0.7)

c("#00008b","#FF007F")
X.train = matrix(c(rep(1,6400),ICE_train$x.coords,ICE_train$y.coords),ncol=3)
Est_origin = X.train%*%matrix(final_estimate[1:3],ncol=1) + W.hat
Est_origin[Est_origin<0] = 0
Est_origin[Est_origin>0] = 1

temp3 = as.data.frame(cbind(Est_origin,ICE_train$x.coords,ICE_train$y.coords))
temp3_1 = temp3[temp3[,1]==1,]
temp3_0 = temp3[temp3[,1]==0,]
plot(x=temp3_1$V3,y=temp3_1$V2,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Estimated Ice Sheet Presence")
points(x=temp3_0$V3,y=temp3_0$V2,col="#00008b",pch=16,cex=0.7)


temp4_1 = as.data.frame(ICE_test[ICE_test$Y==1,])
temp4_0 = as.data.frame(ICE_test[ICE_test$Y==0,])
plot(x=temp4_1$y.coords,y=temp4_1$x.coords,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Hold-out Ice Sheet Presence")
points(x=temp4_0$y.coords,y=temp4_0$x.coords,col="#00008b",pch=16,cex=0.7)

X.test = matrix(c(rep(1,1600),ICE_test$x.coords,ICE_test$y.coords),ncol=3)
Pred_origin = X.test%*%matrix(final_estimate[1:3],ncol=1) + W.star
Pred_origin[Pred_origin<0] = 0
Pred_origin[Pred_origin>0] = 1

temp5 = as.data.frame(cbind(Pred_origin,ICE_test$x.coords,ICE_test$y.coords))
temp5_1 = temp5[temp5[,1]==1,]
temp5_0 = temp5[temp5[,1]==0,]
plot(x=temp5_1$V3,y=temp5_1$V2,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Predicted Ice Sheet Presence")
points(x=temp5_0$V3,y=temp5_0$V2,col="#00008b",pch=16,cex=0.7)

#- SAVE PLOT -#

pdf("ICESheetPredcition.pdf", width=10, height=10)
par(mfrow=c(2,2))
par(mar=c(3,3,3,3))

plot(x=temp2_1$y.coords,y=temp2_1$x.coords,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Observed Ice Sheet Presence")
points(x=temp2_0$y.coords,y=temp2_0$x.coords,col="#00008b",pch=16,cex=0.7)

plot(x=temp3_1$V3,y=temp3_1$V2,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Estimated Ice Sheet Presence")
points(x=temp3_0$V3,y=temp3_0$V2,col="#00008b",pch=16,cex=0.7)

plot(x=temp4_1$y.coords,y=temp4_1$x.coords,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Hold-out Ice Sheet Presence")
points(x=temp4_0$y.coords,y=temp4_0$x.coords,col="#00008b",pch=16,cex=0.7)

plot(x=temp5_1$V3,y=temp5_1$V2,col="red",pch=16,cex=0.7,xlab="",ylab="",main="Predicted Ice Sheet Presence")
points(x=temp5_0$V3,y=temp5_0$V2,col="#00008b",pch=16,cex=0.7)

dev.off()

