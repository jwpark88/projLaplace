rm(list=ls())
##########################################################################################################

source("poisDiscreteFLsource.R")

##############################################################################################################
########################################                DISCRETE             #################################
##############################################################################################################
set.seed(1)
n = 30
A = adjacency.matrix(n)
Q = diag(rowSums(A),n^2) - A
x = rep(0:(n - 1) / (n - 1), times = n) 
y = rep(0:(n - 1) / (n - 1), each = n) 
X = cbind(x, y)                                 # Use the vertex locations as spatial covariates.
beta = c(1, 1)                                  # These are the regression coefficients.
P.perp = diag(1,n^2) - X%*%solve(t(X)%*%X)%*%t(X)
eig = eigen(P.perp %*% A %*% P.perp)
eigenvalues = eig$values
q=400
M = eig$vectors[,c(1:q)]
Q.s = t(M) %*% Q %*% M
tau = 6
Sigma = solve(tau*Q.s)
set.seed(1)
delta.s = mvrnorm(1, rep(0,q), Sigma)
lambda = exp( X%*%beta + M%*%delta.s )
Z = c()
for(j in 1:n^2){Z[j] = rpois(1,lambda[j])}
Y = as.matrix(Z,ncol=1)
data = data.frame("Y"=Y,"X"=X)
colnames(data) = c("Y","X1","X2")
linmod <- glm(Y~-1+X1+X2,data=data,family="poisson") # Find starting values
linmod$coefficients
starting <- c(linmod$coefficients,"logtau"=log(1/var(linmod$residuals)) )

disc.25 <- glgm(Y~-1+X1+X2, inits = starting, data=data, nugget=FALSE, family="poisson", ntrial=1,
                method.optim="BFGS", method.integrate="NR", predict=TRUE, rank=25, A=A)
disc.50 <- glgm(Y~-1+X1+X2, inits = starting, data=data, nugget=FALSE, family="poisson", ntrial=1,
                method.optim="BFGS", method.integrate="NR", predict=TRUE, rank=50, A=A)
disc.75 <- glgm(Y~-1+X1+X2, inits = starting, data=data, nugget=FALSE, family="poisson", ntrial=1,
                method.optim="BFGS", method.integrate="NR", predict=TRUE, rank=75, A=A)
disc.100 <- glgm(Y~-1+X1+X2, inits = starting, data=data, nugget=FALSE, family="poisson", ntrial=1,
                 method.optim="BFGS", method.integrate="NR", predict=TRUE, rank=100, A=A)


##############################################################################################################
########################################                RESULT             ###################################
##############################################################################################################


disc.table(est = disc.25[1][[1]]@coef[,1], se = disc.25[1][[1]]@coef[,2], time = as.numeric(disc.25[2][[1]]))
disc.table(est = disc.50[1][[1]]@coef[,1], se = disc.50[1][[1]]@coef[,2], time = as.numeric(disc.50[2][[1]]))
disc.table(est = disc.75[1][[1]]@coef[,1], se = disc.75[1][[1]]@coef[,2], time = as.numeric(disc.75[2][[1]]))
disc.table(est = disc.100[1][[1]]@coef[,1], se = disc.100[1][[1]]@coef[,2], time = as.numeric(disc.100[2][[1]]))

