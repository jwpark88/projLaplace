rm(list=ls())
##########################################################################################################

source("FLsource.R")
source("FLSimulsource.R")

###########################################################################################################
##########################################    CHANGE HERE    ###################################################
###########################################################################################################

###### number of observation & seed & etc.
N= 1000                       # Number of data
SEED = c(1:100)               # save SEED
ITER = length(SEED)           # Number of iteration
RANK = 100                    # Number of Rank
FAMILY = "binomial"           # FAMILY
CALCULATE_HESSIAN = T         # save HESSIAN


###########################################################################################################
##########################################    SAVE      ###################################################
###########################################################################################################
if(FAMILY=="negative.binomial") {
  PARLENGTH = 5
  PARNAME = c("beta1","beta2","logsigma2","logphi","logprec")
} else {
  PARLENGTH = 4
  PARNAME = c("beta1","beta2","logsigma2","logphi")
}
RESULT.EST = matrix(NA,nrow=ITER,ncol=PARLENGTH) ; colnames(RESULT.EST) <- PARNAME
RESULT.HESS = list()
RESULT.TIME = c()
RESULT.CONV = c()
###########################################################################################################
##########################################     RUN     ###################################################
###########################################################################################################

for(i in 1:ITER) {
  ######-      set SEED       -######
  SEED.TEMP <- SEED[i] 
  set.seed(SEED.TEMP)
  ######- simulate random data -######
  TEMP = rglmm.sim(family=FAMILY,seed=SEED.TEMP,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=N,n.pred=400)
  Y <- TEMP$Y.all[1:N]  ;  Y.all <- TEMP$Y.all
  X <- TEMP$X.all[1:N,] ;  X.all <- TEMP$X.all
  dist <- TEMP$dist.all[1:N,1:N] ; dist.all <- TEMP$dist.all
  coords<- TEMP$coords.all[1:N,] ; coords.all <- TEMP$coords.all
  V <- TEMP$V.all[1:N,1:N]  ;  V.all <- TEMP$V.all
  r.e <- TEMP$r.e.all[1:N]  ;  r.e.all <- TEMP$r.e.all
  Y <- as.matrix(Y,nrow = N)
  n.beta <- dim(X)[2]   
  mat.dist = as.matrix(rdist(coords,coords))
  data = data.frame(cbind(Y,X,coords))
  colnames(data) = c("Y","X1","X2","coords.x","coords.y")
  startinit <- start.glmm(Y~-1+X1+X2,family=FAMILY,data=data)
  startinit[3] = -startinit[3]
  if(FAMILY=="negative.binomial") {
    names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi","logprec")
    Control <- list(maxit=1000,ndeps=rep(1e-2,5),reltol=0.01)
  } else {
    names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi")
    Control <- list(maxit=1000,ndeps=rep(1e-2,4),reltol=0.01)
  }
  a = Sys.time()
  result.temp <- try(glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                          coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                          offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = CALCULATE_HESSIAN),silent = TRUE)
  b = Sys.time()
  RESULT.TIME[i] <- b-a
  if(class(result.temp) != 'try-error'){
    RESULT.EST[i,1:PARLENGTH] <- result.temp[1][[1]]@coef[,1]
    RESULT.HESS[[i]] = result.temp[3][[1]]
    RESULT.CONV[i] = result.temp[4][[1]]@details$convergence
  } else{
    RESULT.HESS[[i]] = NA
    RESULT.CONV[i] = NA
  }
  print(paste(i,"ITERATION : ", b-a))
}

rownames(RESULT.EST) = as.character(SEED)
RESULT.HESS.MAT = matrix(0,ncol=PARLENGTH)
for(i in 1:ITER){
  if(is.na(RESULT.HESS[[i]])!=TRUE){
    RESULT.HESS.MAT = rbind(RESULT.HESS.MAT,RESULT.HESS[[i]])
  } else{
    NA.TEMP = matrix(NA,ncol=PARLENGTH,nrow=PARLENGTH)
    RESULT.HESS.MAT = rbind(RESULT.HESS.MAT,NA.TEMP)
  }
}
RESULT.HESS.MAT = RESULT.HESS.MAT[-1,]

###########################################################################################################
##########################################      SAVERESULT      ###########################################
###########################################################################################################


write.csv(RESULT.EST,paste(FAMILY,"rank100_est.csv",sep=""),row.names = F)
write.csv(RESULT.HESS.MAT,paste(FAMILY,"rank100_hess.csv",sep=""),row.names = F)
write.csv(RESULT.CONV,paste(FAMILY,"rank100_conv.csv",sep=""),row.names = F)
write.csv(RESULT.TIME,paste(FAMILY,"rank100_time.csv",sep=""),row.names = FALSE)



###########################################################################################################
##########################################     ERROR     ###################################################
###########################################################################################################
est <- read.csv("binomialrank100_est.csv")
hess <- read.csv("binomialrank100_hess.csv")
est
SE <- matrix(NA,ncol=4,nrow=nrow(est))
for(i in 1:nrow(est)){
  tmp.hess <- hess[(4*(i-1)+1):(4*i),]
  tmp.se <- sqrt(diag(solve(tmp.hess)))
  SE[i,] <- tmp.se
}

# error in 19, 73th case.

SEED.ERROR = c(101,102)
RESULT.EST.ERROR = matrix(NA,nrow=length(SEED.ERROR),ncol=PARLENGTH)
colnames(RESULT.EST.ERROR) <- PARNAME
RESULT.HESS.ERROR = list()
RESULT.TIME.ERROR = c()
RESULT.CONV.ERROR = c()
N= 1000                     # Number of data
RANK = 100                  # Number of Rank
FAMILY = "binomial"          # FAMILY
CALCULATE_HESSIAN = T    # save HESSIAN

for(i in 1:length(SEED.ERROR)) {
  ######-      set SEED       -######
  SEED.TEMP <- SEED.ERROR[i]
  set.seed(SEED.TEMP)
  ######- simulate random data -######
  TEMP = rglmm.sim(family=FAMILY,seed=SEED.TEMP,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=N,n.pred=400)
  Y <- TEMP$Y.all[1:N]  ;  Y.all <- TEMP$Y.all
  X <- TEMP$X.all[1:N,] ;  X.all <- TEMP$X.all
  dist <- TEMP$dist.all[1:N,1:N] ; dist.all <- TEMP$dist.all
  coords<- TEMP$coords.all[1:N,] ; coords.all <- TEMP$coords.all
  V <- TEMP$V.all[1:N,1:N]  ;  V.all <- TEMP$V.all
  r.e <- TEMP$r.e.all[1:N]  ;  r.e.all <- TEMP$r.e.all
  Y <- as.matrix(Y,nrow = N)
  n.beta <- dim(X)[2]   
  mat.dist = as.matrix(rdist(coords,coords))
  data = data.frame(cbind(Y,X,coords))
  colnames(data) = c("Y","X1","X2","coords.x","coords.y")
  startinit <- start.glmm(Y~-1+X1+X2,family=FAMILY,data=data)
  startinit[3] = -startinit[3]
  if(FAMILY=="negative.binomial") {
    names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi","logprec")
    Control <- list(maxit=1000,ndeps=rep(1e-2,5),reltol=0.01)
  } else {
    names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi")
    Control <- list(maxit=1000,ndeps=rep(1e-2,4),reltol=0.01)
  }
  a = Sys.time()
  result.temp <- try(glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                          coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                          offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = CALCULATE_HESSIAN),silent = TRUE)
  b = Sys.time()
  RESULT.TIME.ERROR[i] <- b-a
  if(class(result.temp) != 'try-error'){
    RESULT.EST.ERROR[i,1:PARLENGTH] <- result.temp[1][[1]]@coef[,1]
    RESULT.HESS.ERROR[[i]] = result.temp[3][[1]]
    RESULT.CONV.ERROR[i] = result.temp[4][[1]]@details$convergence
  } else{
    RESULT.HESS.ERROR[[i]] = NA
    RESULT.CONV.ERROR[i] = NA
  }
  print(paste(i,"ITERATION : ", b-a))
}

SE.ERROR <- matrix(NA,ncol=4,nrow=length(SEED.ERROR))
for(i in 1:length(SEED.ERROR)){
  tmp.hess <- RESULT.HESS.ERROR[[i]]
  tmp.se <- sqrt(diag(solve(tmp.hess)))
  SE.ERROR[i,] <- tmp.se
}
SE.ERROR

est <- read.csv("binomialrank100_est.csv")
est[101:102,] = RESULT.EST.ERROR
est <- est[-c(19,73),] 
hess <- read.csv("binomialrank100_hess.csv")
for(i in 101:102){
  hess[(4*(i-1)+1):(4*i),] <- RESULT.HESS.ERROR[[i-100]]
}
hess = hess[-c((4*(19-1)+1):(4*19),(4*(73-1)+1):(4*73)),]

write.csv(est,paste(FAMILY,"rank100_est_fixed.csv",sep=""),row.names = F)
write.csv(hess,paste(FAMILY,"rank100_hess_fixed.csv",sep=""),row.names = F)

###########################################################################################################
##########################################     FINAL     ##################################################
###########################################################################################################


est <- read.csv("binomialrank100_est_fixed.csv")
hess <- read.csv("binomialrank100_hess_fixed.csv")
# pdf
pdf("BinSimulLog.pdf",width = 10,height = 4)
par(mfrow=c(1,3))
par(mar=c(2,2,2,2))
boxplot(est[,1],main=expression(beta[1]))
abline(h=1,col=2)
boxplot(est[,2],main=expression(beta[2]))
abline(h=1,col=2)
boxplot(est[,3]-est[,4],main=expression(log(sigma^2/phi)))
abline(h=log(5),col=2)
dev.off()


#100시뮬레이션 테이블
round(mean(est[,1]),3)
round(mean(est[,2]),3)
round(mean(est[,3]),3)
round(mean(est[,4]),3)
round(mean(est[,3]-est[,4]),3)

round(sd(est[,1]),3)
round(sd(est[,2]),3)
round(sd(est[,3]),3)
round(sd(est[,4]),3)
round(sd(est[,3]-est[,4]),3)

round(mean((est[,1]-1)^2),3)
round(mean((est[,2]-1)^2),3)
round(mean((est[,3]-log(1))^2),3)
round(mean((est[,4]-log(0.2))^2),3)
round(mean(((est[,3]-est[,4])-log(5))^2),3)

# COVERAGE #
COVERAGE=matrix(NA,ncol=5,nrow=100)
PARLENGTH = 4
for(i in 1:nrow(est)){
  EST.temp <- est[i,]
  EST.temp[5] = EST.temp[3] - EST.temp[4]
  HESS.temp <- as.matrix(hess[(PARLENGTH*(i-1)+1):(PARLENGTH*i),])
  se.rest.temp <- sqrt(diag(solve(HESS.temp)))
  se.s2phi.temp <- sqrt(t(c(0,0,1,-1))%*%solve(HESS.temp)%*%c(0,0,1,-1))
  se.temp = c(se.rest.temp,se.s2phi.temp)
  L.temp <- EST.temp - 1.96*se.temp
  U.temp <- EST.temp + 1.96*se.temp
  COVERAGE[i,] = c(1,1,log(1),log(0.2),log(5)) <= U.temp & c(1,1,log(1),log(0.2),log(5)) >= L.temp   
}
colMeans(COVERAGE,na.rm = T)

