rm(list=ls())
##########################################################################################################

source("FLsource.R")
source("FLSimulsource.R")

###########################################################################################################
##########################################      BIN     ###################################################
###########################################################################################################

###### number of observation & seed
N= 1000
SEED = 6
FAMILY = "binomial"
###### simulate random data
TEMP = rglmm.sim(family=FAMILY,seed=SEED,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=N,n.pred=400)

###########################################################################################################
##########################################     SET      ###################################################
###########################################################################################################

Y <- TEMP$Y.all[1:N]  ;  Y.all <- TEMP$Y.all
X <- TEMP$X.all[1:N,] ;  X.all <- TEMP$X.all
dist <- TEMP$dist.all[1:N,1:N] ; dist.all <- TEMP$dist.all
coords<- TEMP$coords.all[1:N,] ; coords.all <- TEMP$coords.all
V <- TEMP$V.all[1:N,1:N]  ;  V.all <- TEMP$V.all
r.e <- TEMP$r.e.all[1:N]  ;  r.e.all <- TEMP$r.e.all
#-_-#
# lambda <- TEMP$lambda.all[1:N] ; lambda.all <- TEMP$lambda.all
# pi <- TEMP$pi.all[1:N] ; pi.all <- TEMP$pi.all
# mu <- TEMP$mu.all[1:N] ; # mu.all <- <- TEMP$mu.all[1:N]
#-_-#
Y <- as.matrix(Y,nrow = N)
n.beta <- dim(X)[2]   
mat.dist = as.matrix(rdist(coords,coords))
data = data.frame(cbind(Y,X,coords))
colnames(data) = c("Y","X1","X2","coords.x","coords.y")
startinit <- start.glmm(Y~-1+X1+X2,family=FAMILY,data=data)
if(FAMILY=="negative.binomial") {
  names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi","logprec")
  Control <- list(maxit=1000,ndeps=rep(1e-2,5),reltol=0.01)
} else {
  names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi")
  Control <- list(maxit=1000,ndeps=rep(1e-2,4),reltol=0.01)
}

###########################################################################################################
##########################################      RUN      ##################################################
###########################################################################################################

RANK=25
result.bin.25 <- glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                      coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                      offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = T)
table.bin.25 <- table.rank(result.bin.25)

RANK=50
result.bin.50 <- glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                      coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                      offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = T)
table.bin.50 <- table.rank(result.bin.50)

RANK=75
result.bin.75 <- glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                      coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                      offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = T)
table.bin.75 <- table.rank(result.bin.75)

RANK=100
result.bin.100 <- glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                       coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                       offset = NA,predict=TRUE,control=Control,rank=RANK,n.hessian = T)
table.bin.100 <- table.rank(result.bin.100)


############################################################################################################
##########################################      PRED     ###################################################
############################################################################################################

estimate = result.bin.100[1][[1]]@coef[,1]
estimate[3:4] = exp(estimate[3:4])
pred.glmm.plot(estimate,UM,DM,DELTA.HAT,dist.all,r.e.all,coords.all,save=FALSE)


table.bin.25
table.bin.50
table.bin.75
table.bin.100
