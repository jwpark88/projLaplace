#################################################################################################################
###########################                         DATA GENERATION                           ###################
#################################################################################################################

rglmm.sim <- function(family,seed,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=1000,n.pred=400){
  set.seed(seed)
  p.true = c(kappa,sigma,phi)
  beta.true = beta
  n = n
  n.pred = n.pred
  covfn<-covfndef(p.true[1]) # define the covariance function
  coords.all<- matrix(runif((n+n.pred)*2),ncol=2,nrow=n+n.pred) # simulate data locations
  X.all <- matrix(runif((n+n.pred)*2),ncol=2,nrow=(n+n.pred))
  dist.all <- fields::rdist(coords.all,coords.all) # compute distance matrix
  V.all <- p.true[2]*covfn(dist.all,p.true[3]) # compute covariance matrix
  r.e.all <- mgcv::rmvn(1,rep(0,nrow(coords.all)),V.all) # simulate random effects
  if(family=="poisson"){
    lambda.all <- exp(X.all%*%beta.true+r.e.all) # conditional expection for Poisson process
    Y.all <- rpois(length(lambda.all), lambda.all) # simulate Poisson observations
    return(list(Y.all=Y.all,X.all = X.all,
                dist.all = dist.all,coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                lambda.all=lambda.all))
  }
  if(family=="binomial"){
    pi.all = X.all%*%beta.true + r.e.all # linear model
    p.all <- exp(pi.all)/(1+exp(pi.all)) # compute the probability of z = 1 for binary process
    Y.all <- sapply(p.all, function(x) sample(0:1, 1, prob = c(1-x, x))) # simulate binary observations
    return(list(Y.all=Y.all, X.all = X.all,
                dist.all = dist.all, coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                pi.all = pi.all , p.all=p.all))
  }
  if(family=="negative.binomial"){
    mu.all <- exp(X.all%*%beta.true+r.e.all) # conditional expection for Poisson process
    Y.all <- rnbinom(length(mu.all), mu=mu.all,size=prec) # simulate Poisson observations
    return(list(Y.all=Y.all, X.all = X.all,
                dist.all = dist.all,coords.all=coords.all,
                V.all = V.all, r.e.all = r.e.all,
                mu.all= mu.all))
  }
}


start.glmm <- function(formula,family,data,ntrial=1){
  if(family=="poisson"){
    fit<- glm(formula,data=data,family="poisson") 
    esp <- predict(fit,data)
    sigma <- var( esp - log(Y+1))
    phi <- 0.1*max(dist(coords))                                                                  
    startinit <- c(coef(fit),log(sigma),log(phi))
    return(startinit)
  }
  if(family=="binomial"){
    fit<- glm(formula,data=data,family=binomial) 
    esp <- predict(fit, type="response")
    ntrial = ntrial
    sigma = var(Y/ntrial - esp)
    phi <- 0.1*max(dist(coords))                                                                  
    startinit <- c(coef(fit),log(sigma),log(phi))
    return(startinit)
  }
  if(family=="negative.binomial"){
    fit <- glm.nb(formula,data=data)
    esp <- predict(fit,data)
    sigma <- var( esp - log(Y+1))
    phi <- 0.1*max(dist(coords))
    prec <- fit$theta
    startinit <- c(coef(fit),log(sigma),log(phi))
    startinit[length(startinit)+1] = log(prec)
    return(startinit)
  }
}
