rm(list=ls())
source("FLsource.R")
source("FLSimulsource.R")
library(tidyverse)
# For parallel computing.
library(foreach)
library(doParallel)
library(ggplot2)
ncl <- detectCores()-2
cl <- makePSOCKcluster(ncl) 
registerDoParallel(cl)
###########################################################################################################
##########################################      NB      ###################################################
###########################################################################################################

###### number of observation & seed
N= 1000
N.pred = 400
SEED = 10
FAMILY = "negative.binomial"
###### simulate random data
TEMP = rglmm.sim(family=FAMILY,seed=SEED,beta=c(1,1),kappa=2.5,phi=0.2,sigma=1,prec=2,n=N,n.pred=N.pred)

###########################################################################################################
##################################     GENERATE DATA    ###################################################
###########################################################################################################

Y <- TEMP$Y.all[1:N]  ;  Y.all <- TEMP$Y.all
X <- TEMP$X.all[1:N,] ;  X.all <- TEMP$X.all
dist <- TEMP$dist.all[1:N,1:N] ; dist.all <- TEMP$dist.all
coords<- TEMP$coords.all[1:N,] ; coords.all <- TEMP$coords.all
V <- TEMP$V.all[1:N,1:N]  ;  V.all <- TEMP$V.all
r.e <- TEMP$r.e.all[1:N]  ;  r.e.all <- TEMP$r.e.all
#-_-#
# lambda <- TEMP$lambda.all[1:N] ; lambda.all <- TEMP$lambda.all
# pi <- TEMP$pi.all[1:N] ; pi.all <- TEMP$pi.all
# mu <- TEMP$mu.all[1:N] ; # mu.all <- <- TEMP$mu.all[1:N]
#-_-#
Y <- as.matrix(Y,nrow = N)
n.beta <- dim(X)[2]   
mat.dist = as.matrix(rdist(coords,coords))
data = data.frame(cbind(Y,X,coords))
colnames(data) = c("Y","X1","X2","coords.x","coords.y")
startinit <- start.glmm(Y~-1+X1+X2,family=FAMILY,data=data)
if(FAMILY=="negative.binomial") {
  names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi","logprec")
  Control <- list(maxit=1000,ndeps=rep(1e-2,5),reltol=0.01)
} else {
  names(startinit) <- c(colnames(data)[2:3],"logsigma2","logphi")
  Control <- list(maxit=1000,ndeps=rep(1e-2,4),reltol=0.01)
}


###########################################################################################################
##################################     FINDING INITIAL RANK     ###########################################
###########################################################################################################

P = seq(2,200,by=1)
RES <- foreach(i=1:length(P)) %dopar% {
  library(fields)
  library(geoR)
  #library(geoRglm)
  library(Matrix)
  library(mgcv)
  library(bbmle)
  library(ngspatial)
  library(MASS)
  library(RSpectra)
  source("FLsource.R")
  source("FLSimulsource.R")
  
  # set candidates of rank
  Rank <- P[i]
  # set parameter
  param <- startinit
  #param <- c(1,1,log(1),log(0.2))
  s2 <- exp(startinit['logsigma2'])
  # (2) find M
  COV = s2*matern.cov(phi=exp(param['logphi']),kappa=2.5,mat.dist=dist.all)
  # Construct Synthetic variable.
  eig.res <- eigs_sym(COV[1:N,1:N],k=Rank,which="LA")
  UM <- eig.res$vectors
  DM <- diag(eig.res$values)
  M <- UM %*% DM^0.5
  DATA <- cbind(Y,X,M)
  DATA <- as.data.frame(DATA)
  model <- glm.nb(V1~.-1,data=DATA)
  # Construct Covariates where it will be predicted.
  X.new <- X.all[(N+1):(N+N.pred),]
  S12 <- COV[1:N,(N+1):(N+N.pred)]
  S11 <- COV[1:N,1:N]
  M.pred <- t(S12)%*%solve(S11)%*%M
  X.pred <- cbind(X.new,M.pred)
  X.pred <- as.data.frame(X.pred)
  colnames(X.pred) <- names(model$coefficients)
  y.pred <- predict(model,X.pred,"response")
  CVMSPE <- sqrt(mean((Y.all[(N+1):(N+N.pred)]-y.pred)^2))
}
CVMSPE <- c()
for(i in 1:length(P)){
  CVMSPE[i] <- RES[[i]] 
}
RANK <- P[which.min(CVMSPE)]
stopCluster(cl)
###########################################################################################################
##################################           RANK PLOT          ###########################################
###########################################################################################################

D <- data.frame(Rank=P,CVMSPE=CVMSPE)
P1 <- ggplot(D) + 
  geom_line(aes(x=Rank,y=CVMSPE)) + 
  labs(x="Rank",y="CVMSPE") +
  ggtitle(paste("CVMSPE for ",FAMILY,sep=""))+
  theme_bw() + 
  geom_vline(xintercept=RANK,col="red") 
P1

###########################################################################################################
##################################              RUN             ###########################################
###########################################################################################################

a = Sys.time()
result <- glgm(Y~-1+X1+X2,cov.model="matern",kappa = log(2.5),inits = startinit,data = data,nugget=FALSE,
                    coords = coords,family=FAMILY,method.optim = "CG",method.integrate = "NR",
                    offset = NA,predict=TRUE,control=Control,rank=RANK)
b = Sys.time()
b-a

###########################################################################################################
##################################           PREDICTION         ###########################################
###########################################################################################################

estimate <- result[1][[1]]@coef[,1]
estimate[3:4] <- exp(estimate[3:4])
n = dim(UM)[1]
n.pred = length(r.e.all)-n
UD = UM %*% diag(diag(DM)^0.5)
UD_inv = UM %*% diag(diag(DM)^-0.5)
UD_inv_DU = UM %*% diag(diag(DM)^-1) %*% t(UM)
S.hat = estimate[3] * matern.cov(phi = estimate[4], kappa = 2.5, mat.dist = dist.all)
W.hat = UD %*% DELTA.HAT
W.star = ( 1 / estimate[3] ) *  S.hat[(n+1):(n+n.pred),1:n] %*% UD_inv_DU %*% W.hat
W = r.e.all[1:n]
W.tilda = r.e.all[(n+1):(n+n.pred)]
coords = coords.all[1:n,]
coords.pred = coords.all[(n+1):(n+n.pred),]
r.e = r.e.all[1:n]


A <- as.data.frame(rbind(cbind(coords,W,W.hat),cbind(coords.pred,W.tilda,W.star)))

###########################################################################################################
##################################               PLOT          ############################################
###########################################################################################################

coords <- A[1:N,1:2]
coords.pred <- A[(N+1):(N+N.pred),1:2]
W <- A[1:N,3]
W.hat <- A[1:N,4]
W.tilda <- A[(N+1):(N+N.pred),3]
W.star <- A[(N+1):(N+N.pred),4]

A <- cbind(coords,W)
B <- cbind(coords,W.hat)
C <- cbind(coords.pred,W.tilda)
D <- cbind(coords.pred,W.star)

colnames(A) <- c("x1","x2","Scale")
colnames(B) <- c("x1","x2","Scale")
colnames(C) <- c("x1","x2","Scale")
colnames(D) <- c("x1","x2","Scale")

data <- rbind(A,B,C,D)
data$label <- "Simulated Random Effects"
data[(N+1):(2*N),4] <- "Estimated Random Effects"
data[(2*N+1):(2*N+N.pred),4] <- "Hold-out Random Effects"
data[(2*N+N.pred+1):(2*N + 2*N.pred),4] <- "Predicted Random Effects"


ggplot(data=data) +
  geom_point(aes(x=x1,y=x2,color=Scale),size=2) +
  facet_wrap(~factor(label,levels=unique(label))) + 
  xlab("") +
  ylab("") +
  scale_color_viridis_c(option="magma") + 
  theme_bw() + 
  theme(
    #axis.text = element_text( size = 5 ),
    #axis.text.x = element_text( size = 5 ),
    axis.title = element_text( size = 16, face = "bold" ),
    #legend.position="none",
    strip.text = element_text(size = 15))  
