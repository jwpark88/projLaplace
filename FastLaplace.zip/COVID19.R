rm(list=ls())
library(tidyverse)
source("poisDiscreteFLsource.R")

load("US_Covid19.RData")

str(Corona)

dim(A)

############################################################################################
#########################                Initial value            ##########################
############################################################################################

Corona$White <- Corona$White/100
Corona$Black <- Corona$Black/100
Corona$Male <- Corona$Male/100
Corona$Old <- Corona$Old/100

linmod <- glm(Y~offset(log(Population)) + White + Black +  Male + Old,data=Corona,family="poisson") # Find starting values
linmod$coefficients

starting <- c(linmod$coefficients,"logtau"=log(1/var(linmod$residuals)) )
starting
############################################################################################
#########################                     Run                 ##########################
############################################################################################
a = Sys.time()
result.Corona <- glgm(Y~ 1 + White + Black + Male + Old,data=Corona,inits=starting,nugget=FALSE,family="poisson",method.optim = "BFGS",
                  method.integrate = "NR",predict = TRUE,A = A,rank=300, offset = Corona$Population)
b = Sys.time()
b-a

result.Corona[1][[1]]

############################################################################################
#########################                SAVE RESULTS             ##########################
############################################################################################
# 
# X = cbind(1,Corona$White,Corona$Black,Corona$Male,Corona$Old)
# BETA.HAT <- result.Corona[1][[1]]@coef[,1][-length(result.Corona[1][[1]]@coef[,1])]
# 
#Y.HAT <- exp(X%*%BETA.HAT + M.HAT%*%DELTA.HAT + log(Corona$Population)) 
# 
#res <- data.frame(Y_HAT = Y.HAT,Y = Corona$Y)
#write.csv(res,"CORONAREST.csv",row.names = FALSE)



############################################################################################
#########################                  PLOT                   ##########################
############################################################################################

# Saved Result File : Result_Plot
Result_Plot %>%
   mutate(Value = case_when(value > 1700 ~ 1700,
                            TRUE ~ value)) %>%
   ggplot() +
   geom_polygon(aes(x=long,y=lat,group=group,fill=Value)) +
   facet_wrap(~comparison,nrow=2) +
   scale_fill_viridis_c() +
   theme_bw()

