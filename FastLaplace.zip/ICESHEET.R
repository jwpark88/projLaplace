rm(list=ls())
source("FLsource.R")
source("FLSimulsource.R")
library(tidyverse)
# For parallel computing.
library(foreach)
library(doParallel)
library(ggplot2)
ncl <- detectCores()-2
cl <- makePSOCKcluster(ncl) 
registerDoParallel(cl)
###########################################################################################################
##########################################     SET      ###################################################
###########################################################################################################
load("thickness_obs.RData")
Y.all = thickness.obs
image( thickness.obs )
hist( thickness.obs )

mean(Y.all)

Y.all[thickness.obs>1000] = 1
Y.all[thickness.obs<=1000] = 0

image(Y.all)
dim(Y.all)

x.coords.all = seq(0,1,length=nrow(Y.all))
y.coords.all = seq(0,1,length=nrow(Y.all))
Y.all_vec = as.numeric(Y.all)

x.coords.merge = rep(x.coords.all,each=ncol(Y.all))
y.coords.merge = rep(y.coords.all,times=nrow(Y.all))
ICE = data.frame("Y" = Y.all_vec,"x.coords" = x.coords.merge,"y.coords" = y.coords.merge)
dim(ICE)

N = 4900
N.pred = 1100
set.seed(6)
id.all = sample(1:171^2, N + N.pred, replace=FALSE )  
id.temp = sample(1:(N+N.pred),N,replace=FALSE)     
id.train = sort(id.all[id.temp])
id.test = sort(id.all[-id.temp])
ICE_train = ICE[id.train,]
coords_train <- cbind(ICE_train$x.coords,ICE_train$y.coords)
dim(coords_train)

###########################################################################################################
############################         INITIAL  RANK       ##################################################
###########################################################################################################

train.seed <- sample(1:nrow(ICE_train),N*0.7,replace=FALSE)
rank.train <- ICE_train[train.seed,]
rank.valid <- ICE_train[-train.seed,]
dist.ice.trainvalid <- rdist(rbind(rank.train[,2:3],rank.valid[,2:3]))

fit<- glm(Y~.,data=rank.train,family=binomial) 
esp <- predict(fit, type="response")
ntrial = 1
sigma = var(rank.train$Y/ntrial - esp)
phi <- 0.1*max(dist(coords_train[train.seed,]))                                                                  
startinit <- c(coef(fit),log(sigma),log(phi))
names(startinit) <- c("(intercept)",colnames(ICE_train)[2:3],"logsigma2","logphi")
startinit
FAMILY = "binomial"
#define distance matrix
dist.ice = as.matrix(rdist(coords_train,coords_train))                      
# set parameter
param <- startinit
#param <- c(1,1,log(1),log(0.2))
s2 <- exp(startinit['logsigma2'])
# (2) find M
N=nrow(rank.train)
N.pred = nrow(rank.valid)

COV = s2*matern.cov(phi=exp(param['logphi']),kappa=2.5,mat.dist=dist.ice.trainvalid)
S12 <- COV[1:N,(N+1):(N+N.pred)]
S11 <- COV[1:N,1:N]
S12_S11_inv <- t(S12)%*%solve(S11)
#svd
svd_ice <- svd(COV[1:N,1:N])
X <- rank.train[,2:3]
Y <- rank.train[,1]
X.new <- rank.valid[,2:3]
Y.new <- rank.valid[,1]

P = seq(50,150,by=10)
RES <- foreach(i=1:length(P)) %dopar% {
  library(fields)
  library(geoR)
  #library(geoRglm)
  library(Matrix)
  library(mgcv)
  library(bbmle)
  library(ngspatial)
  library(MASS)
  library(RSpectra)
  source("FLsource.R")
  source("FLSimulsource.R")
  # set candidates of rank
  Rank <- P[i]
  # Construct Synthetic variable.
  UM <- svd_ice$u[,1:Rank]
  DM <- diag(svd_ice$d[1:Rank])
  M <- UM %*% DM^0.5
  DATA <- cbind(Y,X,M)
  DATA <- as.data.frame(DATA)
  colnames(DATA) = paste("V",1:ncol(DATA),sep="")
  model <- glm(V1~.,data=DATA,family=FAMILY)
  # Construct Covariates where it will be predicted.
  M.pred <- S12_S11_inv%*%M
  X.pred <- cbind(rep(1,N.pred),X.new,M.pred)
  X.pred <- as.data.frame(X.pred)
  colnames(X.pred) <- names(model$coefficients)
  y.pred <- predict(model,X.pred,"response")
  CVMSPE <- sqrt(mean((Y.new-round(y.pred))^2))
}
CVMSPE <- c()
for(i in 1:length(P)){
  CVMSPE[i] <- RES[[i]] 
}
RANK <- P[which.min(CVMSPE)]
stopCluster(cl)
# Initial rank : 50
RANK  

###########################################################################################################
##########################################      RUN      ##################################################
###########################################################################################################

#- Initial value -#
fit<- glm(Y~.,data=ICE_train,family=binomial) 
esp <- predict(fit, type="response")
ntrial = 1
sigma = var(ICE_train$Y/ntrial - esp)
phi <- 0.1*max(dist(coords_train))                                                                  
startinit <- c(coef(fit),log(sigma),log(phi))
names(startinit) <- c("(intercept)",colnames(ICE_train)[2:3],"logsigma2","logphi")
startinit

source("FLsource.R")
#- Run -#
a= Sys.time()
result_ICE <- glgm(Y ~ .,cov.model="matern",kappa = log(2.5),inits = startinit,data = ICE_train,nugget=FALSE,
                   coords = coords_train,family="binomial",method.optim = "CG",method.integrate = "NR",ntrial=1,
                   offset = NA,predict=TRUE,control=list(maxit=1000,ndeps=rep(0.01,5),reltol=0.01),rank=RANK)
b=Sys.time()
b-a
result_ICE[1][[1]]

###########################################################################################################
##########################################      SAVE     ##################################################
###########################################################################################################
#  
# write.csv(result_ICE[1][[1]]@coef[,1],"ICE_Estimation.csv",row.names = FALSE)
# write.csv(result_ICE[3][[1]],"ICE_Hessian.csv",row.names = FALSE)
# write.csv(as.numeric(result_ICE[2][[1]][1] + result_ICE[2][[1]][2]),"ICE_time.csv",row.names = FALSE)
# write.csv(result_ICE[3][[1]],"ICE_StdErr.csv",row.names = FALSE)
# write.csv(UM,"ICE_UM.csv",row.names=FALSE)
# write.csv(DM,"ICE_DM.csv",row.names=FALSE)
# write.csv(DELTA.HAT,"ICE_DELTAHAT.csv",row.names=FALSE)
# write.csv(data.frame(Rank = RANK,Seed = 9),"ICE_RANK.csv",row.names = FALSE)
# write.csv(as.data.frame(b-a),"ICE_TIME.csv",row.names = FALSE)
# 


# est <- read.csv("ICE_estimation.csv")
# est <- est$x
# nhess <- read.csv("ICE_Hessian.csv")
# se <- sqrt(diag(solve(nhess)))
# round(est,3)
# round(est - 1.96 * se,3) ; round(est + 1.96 * se,3)
# 
# UM <- read.csv("ICE_UM.csv")
# UM <- as.matrix(UM)
# DM <- read.csv("ICE_DM.csv")
# DM <- as.matrix(DM)
# DELTA.HAT <- read.csv("ICE_DELTAHAT.csv")
# DELTA.HAT <- DELTA.HAT$x


###########################################################################################################
##########################################      PRED     ##################################################
###########################################################################################################

ICE_test = ICE[id.test,]
ICE_data = rbind(ICE_train,ICE_test) 
coords.all = cbind(ICE_data$x.coords,ICE_data$y.coords)
dist.all = rdist(coords.all)

N = dim(ICE_train)[1]
N.pred = dim(ICE_test)[1]
UD = UM %*% diag(diag(DM)^0.5)
UD_inv = UM %*% diag(diag(DM)^-0.5)
UD_invU = UM %*% diag(diag(DM)^-1) %*% t(UM)

final_estimate = result_ICE[1][[1]]@coef[,1]
final_estimate[4:5] = exp(final_estimate[4:5])
S.hat = final_estimate[4] * matern.cov(phi = final_estimate[5], kappa = 2.5, mat.dist = dist.all)

W.hat = UD %*% DELTA.HAT
W.star = ( 1 / final_estimate[3] ) *  S.hat[(N+1):(N+N.pred),1:N] %*% UD_invU %*% W.hat

coords.all
coords = cbind(ICE_train$x.coords,ICE_train$y.coords)
coords.pred = coords.all[(N+1):(N+N.pred),]
c1 = cbind(coords[,2],coords[,1])
c2 = cbind(coords.all[(N+1):(N+N.pred),2],coords.all[(N+1):(N+N.pred),1])
W.all = c(W.hat,W.star)


###########################################################################################################
##########################################      PLOT     ##################################################
###########################################################################################################


temp2_1 = as.data.frame(ICE_train[ICE_train$Y==1,])
temp2_0 = as.data.frame(ICE_train[ICE_train$Y==0,])

X.train = matrix(c(rep(1,N),ICE_train$x.coords,ICE_train$y.coords),ncol=3)
Est_origin = X.train%*%matrix(final_estimate[1:3],ncol=1) + W.hat
Est_origin[Est_origin<0] = 0
Est_origin[Est_origin>0] = 1

temp3 = as.data.frame(cbind(Est_origin,ICE_train$x.coords,ICE_train$y.coords))
temp3_1 = temp3[temp3[,1]==1,]
temp3_0 = temp3[temp3[,1]==0,]


temp4_1 = as.data.frame(ICE_test[ICE_test$Y==1,])
temp4_0 = as.data.frame(ICE_test[ICE_test$Y==0,])

X.test = matrix(c(rep(1,N.pred),ICE_test$x.coords,ICE_test$y.coords),ncol=3)
Pred_origin = X.test%*%matrix(final_estimate[1:3],ncol=1) + W.star
Pred_origin[Pred_origin<0] = 0
Pred_origin[Pred_origin>0] = 1

temp5 = as.data.frame(cbind(Pred_origin,ICE_test$x.coords,ICE_test$y.coords))
temp5_1 = temp5[temp5[,1]==1,]
temp5_0 = temp5[temp5[,1]==0,]


#### ggplot


colnames(temp2_1) <- c("V1","V2","V3") ; colnames(temp2_0) <- c("V1","V2","V3")
colnames(temp4_1) <- c("V1","V2","V3") ; colnames(temp4_0) <- c("V1","V2","V3")
temp2_1$V4 <- "Observed Ice Sheet Presence" ; temp2_0$V4 <- "Observed Ice Sheet Presence"
temp3_1$V4 <- "Estimated Ice Sheet Presence" ; temp3_0$V4 <- "Estimated Ice Sheet Presence"
temp4_1$V4 <- "Hold-out Ice Sheet Presence" ; temp4_0$V4 <- "Hold-out Ice Sheet Presence"
temp5_1$V4 <- "Predicted Ice Sheet Presence" ; temp5_0$V4 <- "Predicted Ice Sheet Presence"
ice <- rbind(temp2_1,temp2_0,temp3_1,temp3_0,
            temp4_1,temp4_0,temp5_1,temp5_0)
#write.csv(ice,"ICE_predres.csv",row.names = F)
#ice <- read.csv("ICE_predres.csv",stringsAsFactors = F)
ice$V1 <- as.factor(ice$V1)
ggplot(data=ice) +
  geom_point(aes(x=V3,y=V2,color=V1)) +
  scale_color_manual(values = c("blue","red"))+
  facet_wrap(~factor(V4,levels=unique(V4))) + 
  xlab("") +
  ylab("") +
  theme_bw() + 
  theme(
    #axis.text = element_text( size = 5 ),
    #axis.text.x = element_text( size = 5 ),
    axis.title = element_text( size = 16, face = "bold" ),
    legend.position="none",
    strip.text = element_text(size = 15))  
